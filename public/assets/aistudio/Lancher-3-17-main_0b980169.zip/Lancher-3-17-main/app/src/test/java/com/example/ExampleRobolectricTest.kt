package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.IconShape
import com.example.data.LauncherSettings
import com.example.data.ThemePalette
import com.example.data.WallpaperType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Launcher3", appName)
  }

  @Test
  fun `verify launcher default settings`() {
    val settings = LauncherSettings()
    assertEquals(5, settings.gridRows)
    assertEquals(4, settings.gridCols)
    assertEquals(IconShape.SQUIRCLE, settings.iconShape)
    assertEquals(ThemePalette.DYNAMIC, settings.themePalette)
    assertEquals(WallpaperType.ABSTRACT, settings.wallpaperType)
    assertNotNull(settings)
  }
}
